1.2.0, 2020-04-07
=============
- Compatibility with Odoo 13 version.
- [multi] Added payment in installments submodule.

1.1.1, 2019-12-16
=============
- Bug fix: incorrect payment amount rounding.

1.1.0, 2019-06-17
=============
- Compatibility with Odoo 11 and 12 versions.
- Added Spanish translation.
- Enable signature algorithm selection (SHA-1 or HMAC-SHA-256).
- Added various configuration options.
- Improve payment details dislay.
- [technical] Manage enabled/disabled features by plugin variant.

1.0.0, 2017-05-01
=============
- Bug fix: authentication error on payment end when request contains accented characters.
- Rename some module files to match Odoo standards.
- Added shipping information in sent form.
- Consider AUTHORISED_TO_VALIDATE transaction status as a pending status.
- Added Sogecommerce supported currencies.
- Added license notices.

0.9.1, 2017-05-01
=============
- Bug fix: relative to generating transaction IDs.
- Process return to shop and IPN calls.

0.9.0, 2017-01-22
=============
- Initial Sogecommerce payment module for Odoo 9 by Sudokeys.